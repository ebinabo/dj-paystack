from django.apps import AppConfig


class DjPaystackConfig(AppConfig):
    name = 'dj_paystack'
